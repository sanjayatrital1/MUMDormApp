INSERT INTO `product` VALUES (1,'panda0.jpg',250,'AC','Brand New','panda',0,true ,2),
(2,'macbookpro0.jpg',1500,'NB','Refurbished','macbookpro',0,true ,2),
(3,'Headphone0.jpg',100,'AC','Brand New','Headphone',0,true ,2),
(4,'Iphone Max0.jpg',1200,'SP','Brand New','Iphone Max',0,true ,2),
(5,'macbookpro0.jpg',2500,'NB','Brand New','macbookpro',0,true ,2),
(6,'HeadPhone0.jpg',200,'AC','refurbished','HeadPhone',0,true ,2);